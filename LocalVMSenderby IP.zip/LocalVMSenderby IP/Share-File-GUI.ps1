```powershell
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ScriptDir = if ($PSScriptRoot) {
    $PSScriptRoot
} else {
    Split-Path -Parent $MyInvocation.MyCommand.Path
}

Set-Location $ScriptDir

$script:listener = $null
$script:serverJob = $null
$script:firewallRuleName = $null

function Test-Admin {
    $currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentUser)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-IPv4Address {
    param (
        [string]$IPAddress
    )

    $parsedIp = $null

    if (-not [System.Net.IPAddress]::TryParse($IPAddress, [ref]$parsedIp)) {
        return $false
    }

    return $parsedIp.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork
}

function Start-HttpShare {
    param (
        [string]$SourceIP,
        [string]$DestinationIP,
        [string]$FilePath,
        [int]$Port
    )

    if (-not (Test-IPv4Address $SourceIP)) {
        [System.Windows.Forms.MessageBox]::Show("IP do remetente inválido.", "Erro", "OK", "Error")
        return
    }

    if (-not (Test-IPv4Address $DestinationIP)) {
        [System.Windows.Forms.MessageBox]::Show("IP do destino inválido.", "Erro", "OK", "Error")
        return
    }

    if ($Port -lt 1 -or $Port -gt 65535) {
        [System.Windows.Forms.MessageBox]::Show("Porta inválida. Use uma porta entre 1 e 65535.", "Erro", "OK", "Error")
        return
    }

    if (-not (Test-Path -LiteralPath $FilePath)) {
        [System.Windows.Forms.MessageBox]::Show("Arquivo não encontrado.", "Erro", "OK", "Error")
        return
    }

    $resolvedFilePath = (Resolve-Path -LiteralPath $FilePath).Path
    $file = Get-Item -LiteralPath $resolvedFilePath
    $fileName = $file.Name
    $encodedFileName = [System.Uri]::EscapeDataString($fileName)

    $url = "http://${SourceIP}:${Port}/$encodedFileName"
    $prefix = "http://${SourceIP}:${Port}/"

    $script:firewallRuleName = "TEMP_HTTP_FILE_SHARE_$Port"

    Get-NetFirewallRule -DisplayName $script:firewallRuleName -ErrorAction SilentlyContinue |
        Remove-NetFirewallRule -ErrorAction SilentlyContinue

    New-NetFirewallRule `
        -DisplayName $script:firewallRuleName `
        -Direction Inbound `
        -Action Allow `
        -Protocol TCP `
        -LocalAddress $SourceIP `
        -LocalPort $Port `
        -RemoteAddress $DestinationIP `
        -Profile Any | Out-Null

    $script:serverJob = Start-Job -ArgumentList $SourceIP, $DestinationIP, $resolvedFilePath, $Port -ScriptBlock {
        param ($SourceIP, $DestinationIP, $FilePath, $Port)

        $file = Get-Item -LiteralPath $FilePath
        $fileName = $file.Name
        $prefix = "http://${SourceIP}:${Port}/"

        $listener = New-Object System.Net.HttpListener
        $listener.Prefixes.Add($prefix)
        $listener.Start()

        while ($listener.IsListening) {
            try {
                $context = $listener.GetContext()
                $request = $context.Request
                $response = $context.Response

                $remoteIp = $request.RemoteEndPoint.Address.ToString()

                if ($remoteIp -ne $DestinationIP) {
                    $response.StatusCode = 403
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes("Acesso negado.")
                    $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    $response.Close()
                    continue
                }

                $requestedFile = [System.Uri]::UnescapeDataString($request.Url.Segments[-1])

                if ($requestedFile -ne $fileName) {
                    $response.StatusCode = 404
                    $buffer = [System.Text.Encoding]::UTF8.GetBytes("Arquivo não encontrado.")
                    $response.OutputStream.Write($buffer, 0, $buffer.Length)
                    $response.Close()
                    continue
                }

                $bytes = [System.IO.File]::ReadAllBytes($file.FullName)

                $response.StatusCode = 200
                $response.ContentType = "application/octet-stream"
                $response.ContentLength64 = $bytes.Length
                $response.AddHeader("Content-Disposition", "attachment; filename=`"$fileName`"")
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
                $response.OutputStream.Close()
            }
            catch {
                break
            }
        }

        if ($listener.IsListening) {
            $listener.Stop()
        }

        $listener.Close()
    }

    return $url
}

function Stop-HttpShare {
    if ($script:serverJob) {
        Stop-Job $script:serverJob -ErrorAction SilentlyContinue
        Remove-Job $script:serverJob -Force -ErrorAction SilentlyContinue
        $script:serverJob = $null
    }

    if ($script:firewallRuleName) {
        Get-NetFirewallRule -DisplayName $script:firewallRuleName -ErrorAction SilentlyContinue |
            Remove-NetFirewallRule -ErrorAction SilentlyContinue

        $script:firewallRuleName = $null
    }
}

if (-not (Test-Admin)) {
    [System.Windows.Forms.MessageBox]::Show("Execute como administrador.", "Permissão necessária", "OK", "Warning")
    exit
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Compartilhar arquivo via HTTP"
$form.Size = New-Object System.Drawing.Size(620, 390)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$labelSource = New-Object System.Windows.Forms.Label
$labelSource.Text = "IP do Windows/remetente:"
$labelSource.Location = New-Object System.Drawing.Point(20, 25)
$labelSource.Size = New-Object System.Drawing.Size(180, 20)
$form.Controls.Add($labelSource)

$textSource = New-Object System.Windows.Forms.TextBox
$textSource.Text = ""
$textSource.Location = New-Object System.Drawing.Point(210, 22)
$textSource.Size = New-Object System.Drawing.Size(360, 22)
$form.Controls.Add($textSource)

$labelDest = New-Object System.Windows.Forms.Label
$labelDest.Text = "IP da VM/destino:"
$labelDest.Location = New-Object System.Drawing.Point(20, 65)
$labelDest.Size = New-Object System.Drawing.Size(180, 20)
$form.Controls.Add($labelDest)

$textDest = New-Object System.Windows.Forms.TextBox
$textDest.Text = ""
$textDest.Location = New-Object System.Drawing.Point(210, 62)
$textDest.Size = New-Object System.Drawing.Size(360, 22)
$form.Controls.Add($textDest)

$labelFile = New-Object System.Windows.Forms.Label
$labelFile.Text = "Arquivo:"
$labelFile.Location = New-Object System.Drawing.Point(20, 105)
$labelFile.Size = New-Object System.Drawing.Size(180, 20)
$form.Controls.Add($labelFile)

$textFile = New-Object System.Windows.Forms.TextBox
$textFile.Location = New-Object System.Drawing.Point(210, 102)
$textFile.Size = New-Object System.Drawing.Size(270, 22)
$form.Controls.Add($textFile)

$buttonBrowse = New-Object System.Windows.Forms.Button
$buttonBrowse.Text = "Selecionar"
$buttonBrowse.Location = New-Object System.Drawing.Point(490, 100)
$buttonBrowse.Size = New-Object System.Drawing.Size(80, 26)
$form.Controls.Add($buttonBrowse)

$labelPort = New-Object System.Windows.Forms.Label
$labelPort.Text = "Porta:"
$labelPort.Location = New-Object System.Drawing.Point(20, 145)
$labelPort.Size = New-Object System.Drawing.Size(180, 20)
$form.Controls.Add($labelPort)

$textPort = New-Object System.Windows.Forms.TextBox
$textPort.Text = "8000"
$textPort.Location = New-Object System.Drawing.Point(210, 142)
$textPort.Size = New-Object System.Drawing.Size(100, 22)
$form.Controls.Add($textPort)

$buttonStart = New-Object System.Windows.Forms.Button
$buttonStart.Text = "Iniciar compartilhamento"
$buttonStart.Location = New-Object System.Drawing.Point(210, 185)
$buttonStart.Size = New-Object System.Drawing.Size(180, 32)
$form.Controls.Add($buttonStart)

$buttonStop = New-Object System.Windows.Forms.Button
$buttonStop.Text = "Parar"
$buttonStop.Location = New-Object System.Drawing.Point(400, 185)
$buttonStop.Size = New-Object System.Drawing.Size(80, 32)
$buttonStop.Enabled = $false
$form.Controls.Add($buttonStop)

$labelCommand = New-Object System.Windows.Forms.Label
$labelCommand.Text = "Comando para rodar na VM:"
$labelCommand.Location = New-Object System.Drawing.Point(20, 240)
$labelCommand.Size = New-Object System.Drawing.Size(250, 20)
$form.Controls.Add($labelCommand)

$textCommand = New-Object System.Windows.Forms.TextBox
$textCommand.Location = New-Object System.Drawing.Point(20, 265)
$textCommand.Size = New-Object System.Drawing.Size(550, 45)
$textCommand.Multiline = $true
$textCommand.ReadOnly = $true
$form.Controls.Add($textCommand)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = "Status: parado"
$statusLabel.Location = New-Object System.Drawing.Point(20, 325)
$statusLabel.Size = New-Object System.Drawing.Size(550, 20)
$form.Controls.Add($statusLabel)

$buttonBrowse.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = "Selecione o arquivo"
    $dialog.Filter = "Todos os arquivos (*.*)|*.*"

    if ($dialog.ShowDialog() -eq "OK") {
        $textFile.Text = $dialog.FileName
    }
})

$buttonStart.Add_Click({
    try {
        $sourceIp = $textSource.Text.Trim()
        $destIp = $textDest.Text.Trim()
        $filePath = $textFile.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($sourceIp)) {
            [System.Windows.Forms.MessageBox]::Show("Informe o IP do Windows/remetente.", "Erro", "OK", "Error")
            return
        }

        if ([string]::IsNullOrWhiteSpace($destIp)) {
            [System.Windows.Forms.MessageBox]::Show("Informe o IP da VM/destino.", "Erro", "OK", "Error")
            return
        }

        if ([string]::IsNullOrWhiteSpace($filePath)) {
            [System.Windows.Forms.MessageBox]::Show("Selecione um arquivo.", "Erro", "OK", "Error")
            return
        }

        $port = 0

        if (-not [int]::TryParse($textPort.Text.Trim(), [ref]$port)) {
            [System.Windows.Forms.MessageBox]::Show("Informe uma porta válida.", "Erro", "OK", "Error")
            return
        }

        $url = Start-HttpShare -SourceIP $sourceIp -DestinationIP $destIp -FilePath $filePath -Port $port

        if ($url) {
            $textCommand.Text = "wget `"$url`""
            $statusLabel.Text = "Status: compartilhando em $url"
            $buttonStart.Enabled = $false
            $buttonStop.Enabled = $true
        }
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "Erro", "OK", "Error")
    }
})

$buttonStop.Add_Click({
    Stop-HttpShare
    $statusLabel.Text = "Status: parado"
    $textCommand.Text = ""
    $buttonStart.Enabled = $true
    $buttonStop.Enabled = $false
})

$form.Add_FormClosing({
    Stop-HttpShare
})

[System.Windows.Forms.Application]::Run($form)
```
